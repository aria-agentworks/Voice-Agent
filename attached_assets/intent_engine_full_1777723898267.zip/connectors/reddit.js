const axios = require('axios');

async function fetchLeads() {
  const queries = ["need help", "looking for tool", "any software"];
  let results = [];

  for (let q of queries) {
    const url = `https://www.reddit.com/search.json?q=${encodeURIComponent(q)}`;
    const res = await axios.get(url, { headers: { 'User-Agent': 'intent-engine' } });

    const posts = res.data.data.children.map(p => ({
      source: "reddit",
      text: p.data.title + " " + p.data.selftext,
      url: p.data.url
    }));

    results = results.concat(posts);
  }

  return results;
}

module.exports = { fetchLeads };
