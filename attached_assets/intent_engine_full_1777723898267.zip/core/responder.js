function generateResponse(text) {
  return `Saw your post about "${text}". I built something that might help. Want to try it?`;
}

module.exports = { generateResponse };
