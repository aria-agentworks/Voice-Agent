const express = require('express');
const { normalize } = require('./core/normalizer');
const { score } = require('./core/scorer');

const reddit = require('./connectors/reddit');
const gmaps = require('./connectors/gmaps');

const app = express();

async function runEngine() {
  let raw = [];
  raw = raw.concat(await reddit.fetchLeads());
  raw = raw.concat(await gmaps.fetchLeads());

  const processed = raw.map(r => {
    const n = normalize(r);
    return { ...n, intent_score: score(n.text) };
  });

  return processed.filter(l => l.intent_score >= 7);
}

app.get('/leads', async (req, res) => {
  const leads = await runEngine();
  res.json(leads);
});

app.listen(3000, () => console.log('Engine running on 3000'));
