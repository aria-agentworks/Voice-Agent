function score(text) {
  text = text.toLowerCase();

  if (text.includes("need help")) return 10;
  if (text.includes("looking for")) return 9;
  if (text.includes("tool")) return 8;
  if (text.includes("recommend")) return 7;

  return 3;
}

module.exports = { score };
