async function fetchLeads() {
  return [
    {
      source: "gmaps",
      text: "Local business without lead capture",
      contact: "email@example.com"
    }
  ];
}

module.exports = { fetchLeads };
