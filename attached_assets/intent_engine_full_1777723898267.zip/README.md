# Intent Engine Full System

## Run
npm install
node index.js

## Endpoint
GET /leads

## Next Steps
- Add Playwright scrapers
- Add auto DM system
- Connect email sending
