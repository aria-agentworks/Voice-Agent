function normalize(raw) {
  return {
    source: raw.source,
    text: raw.text || '',
    contact: raw.contact || null,
    url: raw.url || null
  };
}

module.exports = { normalize };
